Hello, 

Thank you for testing an early version of my application: 'CYAN - Choose Your Adventure Neatly'.
CYAN is a tool that enables you to write/read interactive stories.

NOTE - IF YOU ARE REPLACING AN EARLIER VERSION OF CYAN, PLEASE OPEN YOUR PREVIOUSLY MADE STORIES 
	IN THIS VERSION OF CYAN WRITER, OR THEY MAY NOT WORK IN THIS VERSION OF CYAN READER.

It should be fairly usable for the most part. There are definitely bugs, however. 
Some that I'm aware of, and probably a few that I'm not.
	
There are also features that are planned and unimplemented, or only partly implemented 
(you can open the player editor but this currently has no bearing on the story).

I appreciate you trying out this app, and I would be really grateful if you would complete this 
short questionaire after using the app for a while:

https://forms.gle/CbW185K85bBgRWqf6
or click the "CYAN Survey" shortcut in the folder

I'm really looking forward to reading some of your stories too (you can upload them to the survey).

SETUP:
The folder provided should contain everything needed to run on a Windows PC, 
simply double-click CYAN.jar.
If you recieve an error, try installing jdk 19, shortcut in folder, or if it's not in the folder,
you can download it here: 
https://download.oracle.com/java/19/latest/jdk-19_windows-x64_bin.exe

if you are using a linux PC, assuming you have jdk 19 installed, 
you should be able to navigate to the folder in terminal and run with the command: 
java -jar CYAN.jar

USE:
If everything is set up properly, you should see a menu with "Write Story" & "Read Story". 
You can either jump in and start writing a story, or you can try and read the Demo story 
"The Hallway". 
To read The Hallway, click Read Story > Begin Story then select The_Hallway.json 
from the folder provided. 
You can also read your own stories in the same way.
To write your own story, click Write Story, and then click "S1" to edit that first situation,
you can then add choices underneath for the reader to chose from. 
Click the '+' buttons to add more situations.
DON'T FORGET! When you're done, to click File > Save Story to save what you've done.
similarly, when you want to edit a story, click File > Load Story.

Thank you again, and if you have any feedback after completing the survey, 
or any further stories, feel free you email them to me at sa19530@essex.ac.uk

Kind Regards,

Spike
